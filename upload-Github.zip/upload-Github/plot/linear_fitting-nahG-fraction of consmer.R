
#install.packages("rstudioapi")  
library(rstudioapi)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()  
#dir() 

data<-read.csv("./relative fraction-sim.csv",stringsAsFactors = FALSE,check.names = FALSE)
#heading
names(data)=c("x","y","Relative_abundance")


library(ggplot2)

#ggsave("step 1-fitting of redundancy and biomass.eps",height=6,width=8)
pdf("迁出与shannon index线性拟合log.pdf",height=6,width=8)
par(mar=c(3,5,2,2))

p <- ggplot(data, aes(x, y)) +
  ylim(0.4, 0.6)+
  geom_point(color = 'red')+
  geom_smooth(method = 'lm',se=TRUE)+
  theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'), 
        legend.position = 'none', plot.title = element_text(hjust = 0.5),axis.text= element_text(size=12,color="black"),
        axis.title.x=element_text(size=14),axis.title.y=element_text(size=14))+
  labs(x = 'nahG concentration', y = 'Consumer fraction')

fit <- lm(data$y~data$x, data = data)
summary(fit)  

intercept=round(summary(fit)$coefficients[1],2) 
slope=round(summary(fit)$coefficients[2],2)
#p.value
p.value=summary(fit)$coefficients[2,4]
R2=summary(fit)["r.squared"] 
adjR2=summary(fit)["adj.r.squared"]


label_fit <- data.frame(
  formula = sprintf('italic(Y) == %.7f*italic(X) + %.3f', round(coefficients(fit)[2],2), round(coefficients(fit)[1],2)),
  R2 = sprintf('italic(R^2) == %.3f', summary(fit)$adj.r.squared),
  p_value = sprintf('italic(P) == %.3f', summary(fit)$coefficients[2,4]))
  

p +
  geom_text(x = 0.04, y = 0.6, aes(label = formula), data = label_fit, parse = TRUE, 
            hjust = 0, color = 'black', show.legend = FALSE) +
  geom_text(x = 0.04, y = 0.58, aes(label = R2), data = label_fit, parse = TRUE, 
            hjust = 0, color = 'black', show.legend = FALSE) +
  geom_text(x = 0.04, y =0.56, aes(label = p_value), data = label_fit, parse = TRUE, 
            hjust = 0, color = 'black', show.legend = FALSE) 
dev.off() 



