#extract 1000 replicates for analysis
library(rstudioapi)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
path <-getwd()

#new pathway
folderpath1 <- paste(as.character(path),"/","data8-fraction and growth rate analysis",sep="")
setwd(folderpath1) 

table_list <- c("0.025","0.05","0.1","0.2","0.4")
all.table <- NULL
for(i in 1:length(table_list)){
  data_1<-paste("./",as.character(table_list[[i]]),"-relative fraction-sim.csv",sep = "") 
  data1<-read.csv(data_1,header = F)
  all.table <- rbind(all.table,data1)
}
#add column
all.table$ para <-rep(c("0.025","0.05","0.1","0.2","0.4"),
                           c(nrow(all.table)/5,nrow(all.table)/5,nrow(all.table)/5,nrow(all.table)/5,nrow(all.table)/5))

#add heading
names(all.table)<-c("e1","consumer_fraction","producer_fraction","para")

library(dplyr)
library(tidyr)
#split
datanew <- all.table %>% separate(e1, c("e1","replicate"), "-")
write.csv(datanew,"y-e1-fraction-sim.csv",row.names=FALSE)

sig_data <-NULL
datanew <- data.frame(lapply (datanew,as.numeric))
for(j in 1:length(table_list)){
#spearman
data_j<-datanew[which(datanew$para==table_list[[j]]),]
res<-cor.test(data_j$e1, data_j$consumer_fraction, method="spearman")
sig_data <- rbind(sig_data,cbind(para=as.character(table_list[[j]]), r=res$estimate, p=res$p.value))
}
write.csv(sig_data,"y-e1-fraction-sigfi_test.csv",row.names=FALSE)
