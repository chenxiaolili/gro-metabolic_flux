
library(rstudioapi)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
#getwd()   

table_list <- c("0.001","0.005", "0.01", "0.05","0.1","1")

all.table <- as.data.frame(matrix(nrow=0,ncol=3))
for(i in 1:length(table_list)){
  data_1<-paste("./",as.character(table_list[[i]]),"-relative fraction-sim.csv",sep = "") 
  data1<-read.csv(data_1,header = F)
  all.table <- rbind(all.table,data1)
}

all.table$ diffusion <-rep(c("0.001","0.005", "0.01", "0.05","0.1","1"),
                           c(nrow(all.table)/6,nrow(all.table)/6,nrow(all.table)/6,nrow(all.table)/6,nrow(all.table)/6,nrow(all.table)/6))

names(all.table)<-c("e1","consumer_fraction","producer_fraction","diffusion")

library(dplyr)
library(tidyr)
#split
datanew <- all.table %>% separate(e1, c("e1","replicate"), "-")

write.csv(datanew,"diffusion-e1-relative_fraction-sim.csv",row.names=FALSE)

#select
datanew <- datanew[which(datanew$`diffusion`!= 0.001),]
datanew <- datanew[which(datanew$`e1`!= 0.001),]


#plot
library(reshape2)
library(ggplot2)
##Bubble plot
par(mar=c(3,5,2,2))
ggplot(datanew,aes(x=e1,y=diffusion))+
  geom_point(aes(color=producer_fraction,size=producer_fraction))+
  theme(panel.background = element_blank(),
        panel.grid = element_line(color="grey"),
        axis.title = element_blank(),
        axis.ticks = element_blank(),
        legend.position = "right",
        axis.text = element_text(size = 20,face = "plain",color ='black'),
        #axis.title = element_text(size = 12,color ='black'),
        legend.text = element_text(size = 20,color ='black'))+
  guides(color='none',size=guide_legend(title.position = "top", title.hjust = 0.5))+
  labs(size="The producer fraction")+
  scale_color_viridis_c()+
  scale_size_continuous(range = c(1,10))
dev.off()
ggsave("./diffusion-e1-bubble.pdf",height=10,width=12)


