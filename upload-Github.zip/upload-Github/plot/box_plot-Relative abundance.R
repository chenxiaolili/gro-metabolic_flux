
#install.packages("rstudioapi") 
library(rstudioapi)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()   
dir() 

#
library(ggplot2)
library(ggpubr)
library(ggsci)
library(ggsignif)


par(mar=c(3,5,2,2))
data<-read.csv("./relative fraction-sim.csv",stringsAsFactors = FALSE,check.names = FALSE)

names(data)=c("Rhamnosus_concentration","consumer_fraction","Relative_abundance")

p <- ggboxplot(data, x = "Rhamnosus_concentration", y = "Relative_abundance",color = "Rhamnosus_concentration",add="jitter")
#p1=p+stat_compare_means(method = "kruskal.test",label.y = 7.5,label.x = 0.9,size = 4, colour = "black")    
#p1
p2=p+labs(x = 'Rhamnose concentration（W/V）', y = 'Relative abundance of producer') +
  theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'))+
  theme(axis.text= element_text(size=14,color="black"),
        axis.title.x=element_text(size=16),axis.title.y=element_text(size=16))+
  theme(legend.position = 'none')+
  ylim(0.3,0.6)
#theme(panel.border = element_rect(fill=NA,color="black", size=2, linetype="solid"))

dev.off()
ggsave("relative fraction-sim.pdf",height=6,width=8)
dev.new()

par(mar=c(3,5,2,2))
data<-read.csv("./relative fraction-sim.csv",stringsAsFactors = FALSE,check.names = FALSE)#row.names= 1表示第一列设为行名 

names(data)=c("Rhamnosus_concentration","consumer_fraction","Relative_abundance")

p <- ggboxplot(data, x = "Rhamnosus_concentration", y = "consumer_fraction",color = "Rhamnosus_concentration",add="jitter")
#p1=p+stat_compare_means(method = "kruskal.test",label.y = 7.5,label.x = 0.9,size = 4, colour = "black")    #加入总体方差分析计算的p值
#p1
p2=p+labs(x = 'Rhamnose concentration（W/V）', y = 'Relative abundance of [0, 1]') +
  theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent'))+
  theme(axis.text= element_text(size=14,color="black"),
        axis.title.x=element_text(size=16),axis.title.y=element_text(size=16))+
  theme(legend.position = 'none')+
  ylim(0.3,0.6)
#theme(panel.border = element_rect(fill=NA,color="black", size=2, linetype="solid"))

dev.off()
ggsave("Relative_abundance_of_[0, 1]-sim.pdf",height=6,width=8)
dev.new()